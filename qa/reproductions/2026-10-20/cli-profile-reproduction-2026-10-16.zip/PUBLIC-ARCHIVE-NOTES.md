# Reproduction source and original evidence

Original capture date: 2026-10-16. Original reviewed commit: a5abd50c80a0955b729d33ece1b120ca7480e53a. The recorded app/client was run before and after the suggested fix on that revision. Fresh branch-level tests are published separately; these captures were not rerun on the latest upstream revision.

Use the bundled build-and-run script with disposable local profiles.
