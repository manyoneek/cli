# RevenueCat CLI profile-selection reproduction

Source: `RevenueCat/cli` at `a5abd50c80a0955b729d33ece1b120ca7480e53a`.

## Run

Requires Go 1.26.9+ and Python 3.9+. The first build downloads pinned Go dependencies.

```sh
bash build-and-run.sh
```

The script extracts the complete pinned upstream source into a fresh temporary directory, builds it, runs six real CLI commands against credential-free temporary profiles, applies `suggested-fix.patch`, and repeats the commands plus the full Go suite. It never calls RevenueCat services. Your existing CLI installation and profiles are untouched. Temporary build files are removed on exit; logs remain in `results/`.

Expected summary: **original 4 passed / 2 failed; fixed 6 passed / 0 failed**.

## Files

- `report.md`: defect, steps, impact, suggested solution, and verification limits.
- `cli-source.tar.gz`: complete source archive from the exact commit, including its license.
- `qa_profile_precedence_test.go`: regression that invokes the actual Cobra command tree through the existing test helper.
- `reproduce.py`: standalone real-binary command checks. Run `python3 reproduce.py /absolute/path/to/rc`.
- `suggested-fix.patch`: two-line local diagnostic fix.
- `evidence/`: before/after screenshots, videos, command output, binary provenance, and video metadata.
- `logs/`: existing baseline, failing/fixed regressions, full fixed suite, and source-package rebuild results.

## Optional live command viewer

Build both binaries from the supplied source (apply the patch only for the fixed binary), then run:

```sh
python3 viewer.py --before /path/to/rc-before --fixed /path/to/rc-fixed
```

Open `http://127.0.0.1:8886`. Each button runs the six actual subprocesses; it does not replay saved results. `record-cli.cjs` is the capture source used on this host, using the existing managed OpenClaw Chrome profile and Playwright. Its local Playwright path may need adjustment elsewhere. The screenshots/video are CLI evidence, not a web SDK or mobile app reproduction.
