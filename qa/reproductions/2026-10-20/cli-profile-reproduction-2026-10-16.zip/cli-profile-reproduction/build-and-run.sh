#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
# Requires Go 1.26.9+ and Python 3.9+. All commands use synthetic local profiles.
# First build downloads the source tree's pinned Go dependencies.
repro_source_dir="$PWD"
repro_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/rc-profile-build.XXXXXX")"
trap 'rm -rf "$repro_build_dir"' EXIT
mkdir -p results
tar -xzf cli-source.tar.gz -C "$repro_build_dir"
cp qa_profile_precedence_test.go "$repro_build_dir/internal/cli/"
(cd "$repro_build_dir" && go build -o "$repro_build_dir/rc-before" ./cmd/rc)
set +e
python3 reproduce.py "$repro_build_dir/rc-before" --output results/before.json
before_exit=$?
(cd "$repro_build_dir" && go test -json ./internal/cli -run TestQAProfilePrecedence -count=1) > results/test-before.jsonl 2> results/test-before.stderr
test_before_exit=$?
set -e
if [[ "$before_exit" != 1 || "$test_before_exit" != 1 ]]; then
  echo "Unexpected baseline exit: command=$before_exit test=$test_before_exit" >&2
  exit 2
fi
(cd "$repro_build_dir" && git apply "$repro_source_dir/suggested-fix.patch")
(cd "$repro_build_dir" && go build -o "$repro_build_dir/rc-fixed" ./cmd/rc)
python3 reproduce.py "$repro_build_dir/rc-fixed" --output results/fixed.json
(cd "$repro_build_dir" && go test -json ./... -count=1) > results/test-fixed.jsonl 2> results/test-fixed.stderr
printf '%s\n' 'Verified: original 4 passed / 2 failed; fixed 6 passed / 0 failed. Full fixed suite passed.'
