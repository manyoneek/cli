# Review coverage — 2026-10-16

## Inventory

Refreshed all 77 public RevenueCat repositories, including 21 forks and 3 archives. All 77 local clone origins match the corresponding public repositories. No new clones or clone failures. Saved complete GitHub API inventory and clone verification. Fetched review candidates' default branches into detached worktrees; original clones were preserved.

## Native SDK rotation

- **purchases-unity**, `e11533f5a0bcebd2e11fc33b0aca58f5933f90f5`: bounded source review of `Purchases.cs` callbacks, attributes and currency cache, iOS C# forwarding, `PurchasesUnityHelper.m` nil forwarding, `VirtualCurrencies`, `StoreTransaction`, paywall presenter selection and behavior. PHC dependency is exactly 19.13.0. The reviewed iOS currency cache returns NULL and the C# public API checks null/empty strings; no duplicate of the Cordova nil-to-empty-object defect was established. Existing tests require Unity's editor; only Unity Hub is installed, with no editor available in the checked installation locations. No Unity tests or app execution claimed.
- **purchases-kmp**, `8bd6c03d3aa108467c9028b8d53f372b9f482508`: limited Apple/Android virtual-currency mapping and Apple transaction mapping review. Android dependency is 10.27.0. `./gradlew iosSimulatorArm64Test --no-daemon` failed before Gradle startup because no Java runtime is installed. No functional defect or executed KMP coverage claimed.
- **purchases-hybrid-common**, `719ef6cee7fe545d87805b6e4f1d38540846b721`: fetched next candidate and read repository/test setup. No implementation review or test execution claimed. Next primary review candidate.

## CLI

**RevenueCat/cli**, `a5abd50c80a0955b729d33ece1b120ca7480e53a`.

Reviewed profile flag/config resolution, command schema lookup, pagination hints, duration parsing, raw API output plumbing, and output/filter contracts. Tests and runnable command reproductions focused on local profile inspection. Existing `go test -json ./...` passed all 13 packages, with 649 passing test/subtest results and no skipped tests.

One new root-cause fingerprint: `cli:profile-inspection:global-profile-flag-discarded`. `profiles show` and `profiles list` discard the root's `--profile` flag and resolve from ambient/saved defaults again. They are one report, not two defects.

Added `TestQAProfilePrecedence` invoking the real command tree via the existing test helper. Six cases include flag-based show/list, explicit-name and active-default controls, positional-name precedence, and unchanged persisted active profile assertions. Before: 4 passing cases, 2 failing cases (the aggregate Go parent also fails). Fixed: all 6 cases pass. Full fixed suite passes all 13 packages, with 656 passing test/subtest results. Actual binaries produce the same 4/2 → 6/0 result using disposable credential-free profile files, without HTTP fixtures or mocked command behavior.

Two-line diagnostic fix saved; production source restored in `finally` and verified byte-for-byte. Focused regression remains as an untracked local test. All original clone statuses match their pre-review states.

## Duplicate excluded

`schema` accepts an unknown/trailing command path and returns a parent/leaf schema with exit 0. Actual command output retained, but **excluded from new reports**: existing upstream issue https://github.com/RevenueCat/cli/issues/147 and open fix https://github.com/RevenueCat/cli/pull/169 match the root cause. Fingerprint: `cli:schema:unconsumed-find-arguments`. No GitHub writes were made. Profile issue search returned no matches; latest 100 PR titles had no matching profile fix. This is a bounded duplicate check.

## Reproduction and delivery


Loopback viewer executes real subprocesses live. Captured before/after screenshots and ~12-second videos in the managed OpenClaw Chrome profile. Screenshots and frames extracted from both videos were visually inspected. Preserve original frame timestamps, capture source, full output, binary hashes, source, patch, and regression logs. Browser output is a viewer for CLI execution, not a web SDK reproduction.

No production purchases, real customer accounts, RevenueCat service calls, support requests, upstream writes, or schedule changes. Delivery is only the scheduled final output to Discord channel 1559550752349884437; delivery receipt is unavailable within the run.

## Setup failures and recovery

Go was absent from PATH. Downloaded official Go 1.26.9 arm64 archive to this run, checked its published SHA-256, and extracted it locally. Host Python lacks `tarfile.extractall(filter=...)`; recovered with system tar after checksum verification. First test command ran from the evidence directory and could not find a module; preserved under `setup-failures`, then ran successfully from the CLI checkout. `rg` is unavailable, so searches used grep/Python. These are setup limitations, not SDK defects.
