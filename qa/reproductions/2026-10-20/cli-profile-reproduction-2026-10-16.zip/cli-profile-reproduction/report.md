# Profile inspection ignores `--profile`

**Repository:** RevenueCat/cli  
**Commit:** `a5abd50c80a0955b729d33ece1b120ca7480e53a`  
**Platform:** macOS arm64; source-built CLI; Go 1.26.9.

`rc profiles show --profile qa-chosen` displays the saved active profile instead of `qa-chosen`. `profiles list` also marks the wrong profile as active for that invocation. Both commands exit successfully.

## Reproduce

Use the attached source package and run `bash build-and-run.sh` with Go 1.26.9+ and Python 3.9+. It builds the actual CLI, runs the six command checks before and after the patch, and runs the fixed test suite.

The minimal manual setup is two credential-free profiles in a temporary `RC_CONFIG_DIR`:

- `qa-base.json`: `{"project_id":"proj_local_base"}`
- `qa-chosen.json`: `{"project_id":"proj_local_chosen"}`
- `.active`: `qa-base`

Clear ambient `RC_PROFILE` and `RC_PROJECT_ID`, then run:

```sh
rc profiles show --profile qa-chosen --json
rc profiles list --profile qa-chosen --json
rc profiles show qa-chosen --json
```

**Expected:** the first command describes `qa-chosen` and its project; the second identifies `qa-chosen` as the effective active profile. The saved `.active` file stays `qa-base`. The documented precedence is flag → environment → saved active profile → default (`internal/config/config.go`, `ProfileName`).

**Actual:** both flag-based commands report `qa-base`; `show` returns `proj_local_base`. The positional-name control correctly returns `qa-chosen` and `proj_local_chosen`.

**Impact:** scripts and developers inspecting a selected profile receive another profile's configuration with exit code 0. This can mislead project-selection checks. No incorrect remote operation is demonstrated.

## Suggested solution

Pass `rt.Globals.Profile` to `config.ProfileName` in `profiles list`. Initialize the name in `profiles show` from that flag, while preserving the explicit positional-name override. Both handlers currently restart profile resolution with an empty name, discarding the flag already read by the root command.

The attached two-line patch passes the same commands and preserves the saved active profile.

## Verification

```sh
go test ./internal/cli -run TestQAProfilePrecedence -count=1
go test ./... -count=1
```

- Existing baseline: all 13 packages pass; 649 passing test/subtest results.
- Focused regression: **4 cases pass / 2 fail before; 6 pass / 0 fail after**.
- Real compiled CLI: the same **4/2 → 6/0** result, including the recorded runs.
- Full fixed suite: all 13 packages pass; 656 passing test/subtest results, including the new parent test and its six cases.
- Independently rebuilt source package reproduces the failure and passes with the fix.
- Production source restored byte-for-byte after verification.

## Evidence and limits

`evidence/before.png`, `before.mp4`, `fixed.png`, and `fixed.mp4` capture a local viewer executing the actual CLI subprocesses. Full stdout, exit codes, binary hashes, regression logs, source, and patch are included. The viewer does not emulate CLI behavior or HTTP responses.

All profiles are disposable synthetic local files. Windows/Linux and real account credentials were not tested. The issue/PR duplicate check was bounded to matching issue searches and the latest 100 PRs; no matching profile report was found.
