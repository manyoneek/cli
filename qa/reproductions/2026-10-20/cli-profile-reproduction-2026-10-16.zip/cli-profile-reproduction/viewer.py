#!/usr/bin/env python3
"""Loopback-only viewer that executes reproduce.py's real CLI commands."""
import argparse,http.server,json,pathlib,time
from reproduce import run
parser=argparse.ArgumentParser(); parser.add_argument('--before',required=True); parser.add_argument('--fixed',required=True); parser.add_argument('--evidence',default='evidence'); parser.add_argument('--port',type=int,default=8886); args=parser.parse_args()
binaries={'before':str(pathlib.Path(args.before).resolve()),'fixed':str(pathlib.Path(args.fixed).resolve())}
evidence=pathlib.Path(args.evidence); evidence.mkdir(exist_ok=True,parents=True)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/':
   data=pathlib.Path(__file__).with_name('viewer.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html'); self.end_headers(); self.wfile.write(data); return
  mode=self.path.removeprefix('/run/')
  if mode not in binaries: self.send_error(404); return
  self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.send_header('Cache-Control','no-cache'); self.end_headers()
  def send(event):
   self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode()); self.wfile.flush()
   if event['event']=='start': time.sleep(.5)
   if event['event']=='result': time.sleep(.8)
  result=run(binaries[mode],send)
  (evidence/(mode+'-recorded-results.json')).write_text(json.dumps(result,indent=2))
  send(dict(event='done',**result))
 def log_message(self,fmt,*a): print(fmt%a,flush=True)
http.server.HTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
