# Current reproduction source

RevenueCat/cli at `836cf0db60310262cb57acf8619ea9a3797ce4e9`. App/client verification performed on October 20, 2026 against this upstream revision and its current pinned SDK dependencies.

Run `bash build-and-run.sh before` and `bash build-and-run.sh fixed` from separate extracted copies. See the linked issue for expected results and reproduction steps. 
