#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
mkdir -p sdk results
tar -xzf sdk-source.tar.gz -C sdk
if [ "$variant" = fixed ]; then (cd sdk && patch -p1 < ../fixes/cli-profile.patch); fi
(cd sdk && go build -o ../rc ./cmd/rc)
python3 reproduce.py ./rc --output "results/$variant.json"
