const {chromium}=require('/opt/homebrew/lib/node_modules/openclaw/node_modules/playwright-core');
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
(async()=>{
 const browser=await chromium.connectOverCDP('http://127.0.0.1:18800');
 const page=browser.contexts()[0].pages().find(p=>p.url().startsWith('http://127.0.0.1:8898'));
 if(!page)throw Error('Local reproduction tab missing');
 await page.setViewportSize({width:1280,height:1060});
 await page.getByRole('button',{name:'Run original CLI',exact:true}).waitFor();
 const cdp=await page.context().newCDPSession(page);
 try{
 for(const mode of ['before','fixed']){
  await page.reload();await page.getByRole('button',{name:'Run original CLI',exact:true}).waitFor();
  const dir=path.join('evidence',mode+'-frames');fs.mkdirSync(dir,{recursive:true});const frames=[];
  const listener=async e=>{const file=String(frames.length).padStart(5,'0')+'.png';frames.push({file,time:e.metadata.timestamp});fs.writeFileSync(path.join(dir,file),Buffer.from(e.data,'base64'));await cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId});};
  cdp.on('Page.screencastFrame',listener);await cdp.send('Page.startScreencast',{format:'png',maxWidth:1280,maxHeight:1060,everyNthFrame:1});
  await page.waitForTimeout(1000);
  await page.getByRole('button',{name:mode==='before'?'Run original CLI':'Run temporary fix',exact:true}).click();
  await page.waitForFunction(()=>window.done===true,{timeout:30000});
  await page.waitForTimeout(3000);await page.screenshot({path:`evidence/${mode}.png`});
  fs.writeFileSync(`evidence/${mode}-visible.txt`,await page.locator('body').innerText());
  await cdp.send('Page.stopScreencast');cdp.off('Page.screencastFrame',listener);
  const end=Date.now()/1000,lines=[];
  frames.forEach((f,i)=>{lines.push(`file '${f.file}'`);lines.push(`duration ${Math.max(.016,(frames[i+1]?.time??end)-f.time).toFixed(6)}`)});
  lines.push(`file '${frames.at(-1).file}'`);fs.writeFileSync(path.join(dir,'frames.ffconcat'),lines.join('\n'));fs.writeFileSync(path.join(dir,'timestamps.json'),JSON.stringify(frames,null,2));
  let ff=spawnSync('ffmpeg',['-y','-f','concat','-safe','0','-i',path.join(dir,'frames.ffconcat'),'-vf','fps=30','-c:v','libx264','-preset','fast','-crf','24','-pix_fmt','yuv420p',`evidence/${mode}.mp4`],{encoding:'utf8'});
  fs.writeFileSync(`evidence/${mode}-encode.log`,ff.stderr);if(ff.status)throw Error(ff.stderr);
  console.log(mode,'recorded',frames.length,'frames');
 }
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
