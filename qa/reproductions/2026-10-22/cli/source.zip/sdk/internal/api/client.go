// Package api is a typed client for the RevenueCat v2 REST API.
//
// Design rules for this package:
//   - One file per resource (customers.go, projects.go, ...).
//   - Methods map 1:1 to REST endpoints; no compositing here.
//   - No CLI concepts (flags, output formats, prompts) leak in. Anything that
//     calls multiple endpoints to build a user-facing view belongs in the cli/
//     package, not here.
//   - All requests take context.Context.
package api

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/revenuecat/cli/internal/httpx"
)

const DefaultBaseURL = "https://api.revenuecat.com/v2"

type Options struct {
	APIKey  string
	BaseURL string
	// CredentialSource names where APIKey came from, for auth-error hints only.
	CredentialSource string
	HTTPClient       *http.Client
	UserAgent        string
	ExtraHeaders     http.Header
}

type cacheEntry struct {
	etag string
	body []byte
}

type Client struct {
	baseURL          *url.URL
	apiKey           string
	credentialSource string
	http             *http.Client
	userAgent        string
	extraHeaders     http.Header
	cache            sync.Map // url string → cacheEntry; GET-only, session-scoped

	Projects        *ProjectsService
	Customers       *CustomersService
	Audiences       *AudiencesService
	Checkpoints     *CheckpointsService
	Entitlements    *EntitlementsService
	Flows           *FlowsService
	Offerings       *OfferingsService
	Experiments     *ExperimentsService
	TargetingRules  *TargetingRulesService
	Packages        *PackagesService
	Products        *ProductsService
	Subscriptions   *SubscriptionsService
	Purchases       *PurchasesService
	Invoices        *InvoicesService
	Webhooks        *WebhooksService
	Paywalls        *PaywallsService
	MediaAssets     *MediaAssetsService
	Fonts           *FontsService
	Charts          *ChartsService
	Metrics         *MetricsService
	Audit           *AuditService
	Apps            *AppsService
	StoreStatePlans *StoreStatePlansService
	StoreState      *StoreStateService
	// add as we go: Discounts, VirtualCurrencies catalog
}

func NewClient(opts Options) *Client {
	base := opts.BaseURL
	if base == "" {
		base = DefaultBaseURL
	}
	u, err := url.Parse(base)
	if err != nil || u.Scheme == "" || u.Host == "" {
		// Never leave baseURL nil/relative — buildURL dereferences it, so a bad
		// URL here would panic on the first request. Callers should validate
		// user input; this is the last-resort guard.
		u, _ = url.Parse(DefaultBaseURL)
	}
	hc := opts.HTTPClient
	if hc == nil {
		hc = &http.Client{Timeout: 30 * time.Second}
	}
	ua := opts.UserAgent
	if ua == "" {
		ua = "revenuecat-cli/dev"
	}
	c := &Client{baseURL: u, apiKey: opts.APIKey, credentialSource: opts.CredentialSource, http: hc, userAgent: ua, extraHeaders: opts.ExtraHeaders}
	c.Projects = &ProjectsService{c: c}
	c.Customers = &CustomersService{c: c}
	c.Audiences = &AudiencesService{c: c}
	c.Checkpoints = &CheckpointsService{c: c}
	c.Entitlements = &EntitlementsService{c: c}
	c.Flows = &FlowsService{c: c}
	c.Offerings = &OfferingsService{c: c}
	c.Experiments = &ExperimentsService{c: c}
	c.TargetingRules = &TargetingRulesService{c: c}
	c.Packages = &PackagesService{c: c}
	c.Products = &ProductsService{c: c}
	c.Subscriptions = &SubscriptionsService{c: c}
	c.Purchases = &PurchasesService{c: c}
	c.Invoices = &InvoicesService{c: c}
	c.Webhooks = &WebhooksService{c: c}
	c.Paywalls = &PaywallsService{c: c}
	c.MediaAssets = &MediaAssetsService{c: c}
	c.Fonts = &FontsService{c: c}
	c.Charts = &ChartsService{c: c}
	c.Metrics = &MetricsService{c: c}
	c.Audit = &AuditService{c: c}
	c.Apps = &AppsService{c: c}
	c.StoreStatePlans = &StoreStatePlansService{c: c}
	c.StoreState = &StoreStateService{c: c}
	return c
}

// do is the single chokepoint for all HTTP. Streaming (SSE) helpers live next
// to it but call into a different path that returns a *http.Response.
func (c *Client) do(ctx context.Context, method, path string, body, out any) error {
	var rdr io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return err
		}
		rdr = bytes.NewReader(b)
	}

	urlStr, err := c.buildURL(path)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, method, urlStr, rdr)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.apiKey)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", c.userAgent)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	httpx.Apply(req, c.extraHeaders)

	// ETag cache: send If-None-Match on repeat GETs.
	if method == http.MethodGet {
		if v, ok := c.cache.Load(urlStr); ok {
			if entry, ok := v.(cacheEntry); ok {
				req.Header.Set("If-None-Match", entry.etag)
			}
		}
	}

	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// 304: serve from cache.
	if resp.StatusCode == http.StatusNotModified {
		if out == nil {
			return nil
		}
		v, ok := c.cache.Load(urlStr)
		if !ok {
			return fmt.Errorf("received 304 but no cached body found for %s", urlStr)
		}
		return json.Unmarshal(v.(cacheEntry).body, out)
	}

	if resp.StatusCode >= 400 {
		return c.annotateError(parseError(resp))
	}
	if out == nil || resp.StatusCode == http.StatusNoContent {
		return nil
	}

	// Read body once so we can both cache it and decode it.
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if method == http.MethodGet {
		if etag := resp.Header.Get("ETag"); etag != "" {
			c.cache.Store(urlStr, cacheEntry{etag: etag, body: data})
		}
	}
	return json.Unmarshal(data, out)
}

// annotateError stamps the client's credential source onto an APIError.
func (c *Client) annotateError(err error) error {
	if ae, ok := err.(*APIError); ok {
		ae.CredentialSource = c.credentialSource
	}
	return err
}

// Page wraps cursor-paginated list responses.
//
// RevenueCat v2 uses Stripe-style envelopes: a full URL in `next_page` is the
// cursor for the next request, or null when exhausted. `object` is always
// "list"; `url` is the canonical URL of this page.
type Page[T any] struct {
	Items    []T    `json:"items"`
	NextPage string `json:"next_page,omitempty"`
	Object   string `json:"object,omitempty"`
	URL      string `json:"url,omitempty"`
}

// Millis is a unix-millisecond timestamp. The v2 API emits these as ints.
type Millis int64

// buildURL combines the client's base URL with a path that may include a
// query string. Query must go in URL.RawQuery, not concatenated into Path —
// otherwise the server receives a literal "?" in the path and 404s.
func (c *Client) buildURL(path string) (string, error) {
	u := *c.baseURL
	if i := strings.IndexByte(path, '?'); i >= 0 {
		u.Path = u.Path + path[:i]
		u.RawQuery = path[i+1:]
	} else {
		u.Path = u.Path + path
	}
	return u.String(), nil
}

func encodePath(parts ...string) string {
	out := ""
	for _, p := range parts {
		out += "/" + url.PathEscape(p)
	}
	return out
}

// Raw executes a raw HTTP request and returns the response body and status code.
// Auth headers are set from the client's bearer token (API key or OAuth access token).
// Useful for the `rc api` passthrough command.
func (c *Client) Raw(ctx context.Context, method, path string, body []byte) ([]byte, int, error) {
	var rdr io.Reader
	if len(body) > 0 {
		rdr = bytes.NewReader(body)
	}
	urlStr, err := c.buildURL(path)
	if err != nil {
		return nil, 0, err
	}
	req, err := http.NewRequestWithContext(ctx, method, urlStr, rdr)
	if err != nil {
		return nil, 0, err
	}
	req.Header.Set("Authorization", "Bearer "+c.apiKey)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", c.userAgent)
	if len(body) > 0 {
		req.Header.Set("Content-Type", "application/json")
	}
	httpx.Apply(req, c.extraHeaders)
	resp, err := c.http.Do(req)
	if err != nil {
		return nil, 0, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, resp.StatusCode, c.annotateError(parseError(resp))
	}
	data, err := io.ReadAll(resp.Body)
	return data, resp.StatusCode, err
}
