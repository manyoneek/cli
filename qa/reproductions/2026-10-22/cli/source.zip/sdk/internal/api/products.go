package api

import (
	"context"
	"net/http"
	"net/url"
)

type ProductsService struct{ c *Client }

// Product type is generated in types_gen.go.

type ProductListOptions struct {
	AppID string
}

type ProductCreate struct {
	StoreIdentifier string                    `json:"store_identifier"`
	Type            string                    `json:"type"` // "subscription" | "one_time"
	AppID           string                    `json:"app_id"`
	DisplayName     string                    `json:"display_name,omitempty"`
	Title           string                    `json:"title,omitempty"`
	Subscription    *ProductSubscriptionInput `json:"subscription,omitempty"`
}

type ProductUpdate struct {
	DisplayName *string `json:"display_name,omitempty"`
}

type ProductPrice struct {
	ID           *string `json:"id"`
	Currency     string  `json:"currency"`
	AmountMicros int64   `json:"amount_micros"`
}

type ProductPriceInput struct {
	Currency     string `json:"currency"`
	AmountMicros int64  `json:"amount_micros"`
}

type ProductPricesCreate struct {
	Prices []ProductPriceInput `json:"prices"`
}

type ProductPriceUpdate struct {
	AmountMicros int64 `json:"amount_micros"`
}

func (s *ProductsService) List(ctx context.Context, projectID string, opts *ProductListOptions) (*Page[Product], error) {
	path := pathProducts(projectID)
	if opts != nil && opts.AppID != "" {
		path += "?app_id=" + url.QueryEscape(opts.AppID)
	}
	var out Page[Product]
	err := s.c.do(ctx, http.MethodGet, path, nil, &out)
	return &out, err
}

func (s *ProductsService) Create(ctx context.Context, projectID string, body ProductCreate) (*Product, error) {
	var out Product
	err := s.c.do(ctx, http.MethodPost, pathProducts(projectID), body, &out)
	return &out, err
}

func (s *ProductsService) Get(ctx context.Context, projectID, id string) (*Product, error) {
	var out Product
	err := s.c.do(ctx, http.MethodGet, pathProduct(projectID, id), nil, &out)
	return &out, err
}

func (s *ProductsService) Update(ctx context.Context, projectID, id string, body ProductUpdate) (*Product, error) {
	var out Product
	err := s.c.do(ctx, http.MethodPost, pathProduct(projectID, id), body, &out)
	return &out, err
}

func (s *ProductsService) ListPrices(ctx context.Context, projectID, productID string) ([]ProductPrice, error) {
	var out []ProductPrice
	path := pathProductPrices(projectID, productID)
	err := s.c.do(ctx, http.MethodGet, path, nil, &out)
	return out, err
}

func (s *ProductsService) CreateTestStorePrices(ctx context.Context, projectID, productID string, body ProductPricesCreate) ([]ProductPrice, error) {
	var out []ProductPrice
	path := pathProductTestStorePrices(projectID, productID)
	err := s.c.do(ctx, http.MethodPost, path, body, &out)
	return out, err
}

func (s *ProductsService) UpdatePrice(ctx context.Context, projectID, productID, currency string, body ProductPriceUpdate) (*ProductPrice, error) {
	var out ProductPrice
	path := pathProductPrice(projectID, productID, currency)
	err := s.c.do(ctx, http.MethodPatch, path, body, &out)
	return &out, err
}

func (s *ProductsService) Delete(ctx context.Context, projectID, id string) error {
	return s.c.do(ctx, http.MethodDelete, pathProduct(projectID, id), nil, nil)
}

func (s *ProductsService) Archive(ctx context.Context, projectID, id string) (*Product, error) {
	var out Product
	path := pathProductActionsArchive(projectID, id)
	err := s.c.do(ctx, http.MethodPost, path, nil, &out)
	return &out, err
}

func (s *ProductsService) Restore(ctx context.Context, projectID, id string) (*Product, error) {
	var out Product
	path := pathProductActionsUnarchive(projectID, id)
	err := s.c.do(ctx, http.MethodPost, path, nil, &out)
	return &out, err
}

// POST /projects/{project_id}/products/{id}/create_in_store
//
// Push the product configuration to the underlying store.
func (s *ProductsService) Push(ctx context.Context, projectID, id string) error {
	path := pathProductCreateInStore(projectID, id)
	return s.c.do(ctx, http.MethodPost, path, nil, nil)
}
