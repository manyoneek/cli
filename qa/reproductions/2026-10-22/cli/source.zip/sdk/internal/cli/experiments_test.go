package cli_test

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestExperimentResultsJSONIncludesAllSegments(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/projects/proj/experiments/exp1/results" {
			t.Errorf("unexpected route: %s", r.URL.Path)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"object":"experiment_results","currency":"USD","sections":[{"object":"experiment_results_section","section":"Revenue","metrics":[{"name":"realized_ltv_per_customer"}],"segments":[{"object":"experiment_results_segment","id":"product","display_name":"Annual","is_total":false}],"values":[{"object":"experiment_results_value","metric":0,"segment":0,"variant":"Treatment","value":12.5,"change":5,"credible_interval":null,"lift_credible_interval":null}]}],"statistics":[],"predicted_ltv":null}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	out, stderr, err := runAgentCmd(t, "experiments", "results", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
	if err != nil || stderr != "" {
		t.Fatalf("err=%v stderr=%q", err, stderr)
	}
	var envelope struct {
		Data struct {
			Sections []struct {
				Segments []struct {
					ID string `json:"id"`
				} `json:"segments"`
			} `json:"sections"`
		} `json:"data"`
		SchemaVersion int `json:"schema_version"`
	}
	if err := json.Unmarshal([]byte(out), &envelope); err != nil {
		t.Fatal(err)
	}
	if envelope.SchemaVersion != 1 || envelope.Data.Sections[0].Segments[0].ID != "product" {
		t.Fatalf("unexpected envelope: %s", out)
	}
}

func TestExperimentResultsNormalizesFilters(t *testing.T) {
	for _, tc := range []struct {
		platform string
		want     string
	}{
		{"ios", "iOS"},
		{"app_store", "iOS"},
		{"iOS", "iOS"},
		{"android", "Android"},
	} {
		t.Run(tc.platform, func(t *testing.T) {
			var platform, exposure string
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				platform = r.URL.Query().Get("platform")
				exposure = r.URL.Query().Get("exposure_status")
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, `{"object":"experiment_results","currency":"USD","sections":[],"statistics":[],"predicted_ltv":null}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			_, _, err := runAgentCmd(t, "experiments", "results", "exp1", "--platform", tc.platform, "--exposure-status", "EXPOSED", "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
			if err != nil || platform != tc.want || exposure != "exposed" {
				t.Fatalf("err=%v platform=%q exposure=%q", err, platform, exposure)
			}
		})
	}
}

func TestExperimentResultsRejectsUnknownExposureStatus(t *testing.T) {
	_, _, err := runCmd(t, "experiments", "results", "exp1", "--exposure-status", "viewed")
	if err == nil || !strings.Contains(err.Error(), "exposure status must be") {
		t.Fatalf("expected supported-value error, got %v", err)
	}
}

func TestExperimentResultsWarnsOnUnknownPlatform(t *testing.T) {
	var platform string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		platform = r.URL.Query().Get("platform")
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"object":"experiment_results","currency":"USD","sections":[],"statistics":[],"predicted_ltv":null}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	_, stderr, err := runAgentCmd(t, "experiments", "results", "exp1", "--platform", "bogus", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err != nil || platform != "bogus" || !strings.Contains(stderr, `Unknown platform "bogus"`) {
		t.Fatalf("err=%v platform=%q stderr=%q", err, platform, stderr)
	}
}

func TestExperimentShowSortsTimeline(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Timeline test","status":"paused","started_at":1000,"paused_at":3000,"resumed_at":2000}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	out, _, err := runAgentCmd(t, "experiments", "show", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	started, resumed, paused := strings.Index(out, "Started:"), strings.Index(out, "Resumed:"), strings.Index(out, "Paused:")
	if err != nil || started < 0 || resumed < 0 || paused < 0 || started > resumed || resumed > paused {
		t.Fatalf("timeline out of order: err=%v out=%s", err, out)
	}
}

func TestExperimentResultsHumanExplainsMissingTotals(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"object":"experiment_results","currency":"USD","sections":[{"section":"Revenue","metrics":[{"name":"revenue"}],"segments":[{"id":"product","display_name":"Annual","is_total":false}],"values":[{"metric":0,"segment":0,"variant":"Treatment","value":12.5}]}],"statistics":[],"predicted_ltv":{"predicted_winner_variant":"b","confidence":85}}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	out, stderr, err := runAgentCmd(t, "experiments", "results", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"No total-segment metrics available", "Use --json", "Predicted winner", "Variant b"} {
		if !strings.Contains(out+stderr, want) {
			t.Fatalf("missing %q in output: stdout=%s stderr=%s", want, out, stderr)
		}
	}
}

func TestExperimentsDiscoverable(t *testing.T) {
	out, _, err := runCmd(t, "schema", "experiments", "results", "--json")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out, `"path": "rc experiments results"`) || strings.Contains(out, `"experimental": true`) {
		t.Fatalf("results command not discoverable as a default command: %s", out)
	}
}

func TestExperimentResultsPreservesPercentageUnitsAndShowsFilters(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"currency":"USD","sections":[],"statistics":[{"metric_name":"trial_conversion_rate","variants":[{"name":"Treatment","chance_to_win":0.98,"lift_credible_interval_lower":-5,"lift_credible_interval_upper":22}]}]}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	out, stderr, err := runAgentCmd(t, "experiments", "results", "exp1", "--platform", "ios", "--country", "us", "--exposure-status", "exposed", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"98.0%", "-5.0% to +22.0%", "iOS", "US", "exposed"} {
		if !strings.Contains(out+stderr, want) {
			t.Fatalf("missing %q: stdout=%s stderr=%s", want, out, stderr)
		}
	}
}

func TestExperimentsListIncludesFourVariantsAndPagination(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		if q.Get("limit") != "5" || q.Get("starting_after") != "exp0" || q.Get("status") != "running" {
			t.Errorf("unexpected query: %s", r.URL.RawQuery)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"items":[{"id":"exp1","display_name":"Four variants","status":"running","offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"},"offering_c":{"id":"ofrng_c"},"offering_d":{"id":"ofrng_d"}}],"next_page":"/projects/proj/experiments?starting_after=exp1"}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	args := []string{"experiments", "list", "--status", "running", "--limit", "5", "--cursor", "exp0", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
	out, stderr, err := runAgentCmd(t, args...)
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"ofrng_a", "ofrng_b", "ofrng_c", "ofrng_d", "--cursor exp1"} {
		if !strings.Contains(out+stderr, want) {
			t.Fatalf("missing %q: stdout=%s stderr=%s", want, out, stderr)
		}
	}
	out, stderr, err = runAgentCmd(t, append(args, "--json")...)
	if err != nil || stderr != "" || !strings.Contains(out, `"next_page"`) || !strings.Contains(out, "ofrng_d") {
		t.Fatalf("pagination or variants missing in JSON: err=%v stdout=%s stderr=%s", err, out, stderr)
	}
}

func TestExperimentShowIncludesPaywallsAndTargeting(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("expand") != "offering.paywall" {
			t.Errorf("missing paywall expansion: %s", r.URL.RawQuery)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Four variants","status":"draft","offering_a":{"id":"ofrng_a","paywall_id":"pw_a"},"offering_b":{"id":"ofrng_b"},"offering_c":{"id":"ofrng_c","paywall_id":"pw_c"},"offering_d":{"id":"ofrng_d"},"targeting_conditions":[{"field":"platform","operator":"in","value":["ios"]},{"field":"country","operator":"in","value":["US"]}]}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	for _, jsonOutput := range []bool{false, true} {
		args := []string{"experiments", "show", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
		if jsonOutput {
			args = append(args, "--json")
		}
		out, _, err := runAgentCmd(t, args...)
		if err != nil {
			t.Fatal(err)
		}
		for _, want := range []string{"pw_a", "pw_c", "ofrng_c", "ofrng_d", "platform", "ios", "country", "US"} {
			if !strings.Contains(out, want) {
				t.Fatalf("missing %q (json=%v): %s", want, jsonOutput, out)
			}
		}
	}
}

func TestExperimentResultsIncludesFourVariants(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"currency":"USD","sections":[{"section":"Conversion","metrics":[{"name":"trial_conversion_rate","unit":"%"}],"segments":[{"is_total":true}],"values":[{"metric":0,"segment":0,"variant":"Control","value":10},{"metric":0,"segment":0,"variant":"Treatment","value":11,"change":10},{"metric":0,"segment":0,"variant":"TreatmentC","value":12,"change":20},{"metric":0,"segment":0,"variant":"TreatmentD","value":13,"change":30}]}],"statistics":[]}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	out, _, err := runAgentCmd(t, "experiments", "results", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{"VARIANT c", "VARIANT d", "+10.00%", "+20.00%", "+30.00%"} {
		if !strings.Contains(out, want) {
			t.Fatalf("missing %q: %s", want, out)
		}
	}
}

func TestExperimentResultsVariantFormats(t *testing.T) {
	for _, tc := range []struct {
		name, control   string
		variants        []string
		wantRow, winner string
	}{
		{"legacy", "", []string{"Control", "Treatment", "TreatmentC", "TreatmentD"}, "trial_conversion_rate 10 11 +10.00% 12 +20.00% 13 +30.00% %", "Variant c"},
		{"legacy with control A", "a", []string{"Control", "Treatment", "TreatmentC", "TreatmentD"}, "trial_conversion_rate 10 11 +10.00% 12 +20.00% 13 +30.00% %", "Variant c"},
		{"legacy with control C", "c", []string{"Control", "Treatment", "TreatmentC", "TreatmentD"}, "trial_conversion_rate 12 10 +0.00% 11 +10.00% 13 +30.00% %", "Control (c)"},
		{"keys without control", "", []string{"a", "b", "c", "d"}, "trial_conversion_rate 10 11 +10.00% 12 +20.00% 13 +30.00% %", "Variant c"},
		{"keys with control A", "a", []string{"a", "b", "c", "d"}, "trial_conversion_rate 10 11 +10.00% 12 +20.00% 13 +30.00% %", "Variant c"},
		{"keys with control B", "b", []string{"a", "b", "c", "d"}, "trial_conversion_rate 11 10 +0.00% 12 +20.00% 13 +30.00% %", "Variant c"},
		{"keys with control C", "c", []string{"a", "b", "c", "d"}, "trial_conversion_rate 12 10 +0.00% 11 +10.00% 13 +30.00% %", "Control (c)"},
		{"keys with control D", "d", []string{"a", "b", "c", "d"}, "trial_conversion_rate 13 10 +0.00% 11 +10.00% 12 +20.00% %", "Variant c"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			values, variants := []any{}, []any{}
			for i, variant := range tc.variants {
				values = append(values, map[string]any{"metric": 0, "segment": 0, "variant": variant, "value": 10 + i, "change": i * 10})
				variants = append(variants, map[string]any{"name": variant, "chance_to_win": float64(i+1) / 10})
			}
			payload := map[string]any{
				"currency": "USD",
				"sections": []any{map[string]any{
					"section": "Conversion", "metrics": []any{map[string]any{"name": "trial_conversion_rate", "unit": "%"}},
					"segments": []any{map[string]any{"is_total": true}}, "values": values,
				}},
				"statistics":    []any{map[string]any{"metric_name": "trial_conversion_rate", "variants": variants}},
				"predicted_ltv": map[string]any{"predicted_winner_variant": "c", "confidence": 85},
			}
			if tc.control != "" {
				payload["control_variant"] = tc.control
			}
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(payload)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			args := []string{"experiments", "results", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
			out, stderr, err := runAgentCmd(t, args...)
			if err != nil {
				t.Fatal(err)
			}
			normalized := strings.Join(strings.Fields(out+stderr), " ")
			if !strings.Contains(normalized, tc.wantRow) || !strings.Contains(normalized, "Predicted winner "+tc.winner) {
				t.Fatalf("incorrect metrics or predicted winner: %s", out)
			}
			control := tc.control
			if control == "" {
				control = "a"
			}
			for i, key := range []string{"a", "b", "c", "d"} {
				signal := fmt.Sprintf("%.1f%%", float64(i+1)*10)
				if strings.Contains(out, signal) != (key != control) {
					t.Fatalf("incorrect decision signal %s for control %s: %s", signal, control, out)
				}
			}
			if !strings.Contains(normalized, "CONTROL ("+control+")") {
				t.Fatalf("missing control identity: %s", out)
			}
			out, stderr, err = runAgentCmd(t, append(args, "--json")...)
			if err != nil || stderr != "" {
				t.Fatalf("err=%v stderr=%s", err, stderr)
			}
			var envelope struct {
				Data          map[string]any `json:"data"`
				SchemaVersion int            `json:"schema_version"`
			}
			if err := json.Unmarshal([]byte(out), &envelope); err != nil {
				t.Fatal(err)
			}
			if envelope.SchemaVersion != 1 || envelope.Data["control_variant"] != payload["control_variant"] {
				t.Fatalf("unexpected JSON envelope: %s", out)
			}
			section := envelope.Data["sections"].([]any)[0].(map[string]any)
			statistic := envelope.Data["statistics"].([]any)[0].(map[string]any)
			for i, variant := range tc.variants {
				value := section["values"].([]any)[i].(map[string]any)
				stat := statistic["variants"].([]any)[i].(map[string]any)
				if value["variant"] != variant || value["value"] != float64(10+i) || stat["name"] != variant {
					t.Fatalf("variant data changed in JSON: %s", out)
				}
			}
			if envelope.Data["predicted_ltv"].(map[string]any)["predicted_winner_variant"] != "c" {
				t.Fatalf("predicted winner changed in JSON: %s", out)
			}
		})
	}
}

func TestExperimentResultsOpaqueVariantKeys(t *testing.T) {
	fixture, err := os.ReadFile("testdata/experiment-results-opaque-keys.json")
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct{ winner, label string }{
		{"f", "Variant f"},
		{"e", "Control (e)"},
	} {
		t.Run(tc.winner, func(t *testing.T) {
			payload := strings.Replace(string(fixture), `"predicted_winner_variant": "f"`, `"predicted_winner_variant": "`+tc.winner+`"`, 1)
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, payload)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			args := []string{"experiments", "results", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
			out, stderr, err := runAgentCmd(t, args...)
			if err != nil {
				t.Fatal(err)
			}
			normalized := strings.Join(strings.Fields(out+stderr), " ")
			for _, want := range []string{
				"METRIC CONTROL (e) VARIANT F CHANGE F VARIANT f CHANGE f VARIANT z CHANGE z UNIT",
				"trial_conversion_rate 10 14 +40.00% 12 +20.00% 13 +30.00% %",
				"paid_conversion_rate 5 — — — — — — %",
				"trial_conversion_rate Variant f 90.0%",
				"trial_conversion_rate Variant F Need more data",
				"Predicted winner " + tc.label,
			} {
				if !strings.Contains(normalized, want) {
					t.Fatalf("missing %q: %s", want, normalized)
				}
			}
			for _, unwanted := range []string{"10.0%", "segment-only", "invalid-metric", "invalid-segment", "VARIANT a", "VARIANT b"} {
				if strings.Contains(normalized, unwanted) {
					t.Fatalf("unexpected %q: %s", unwanted, normalized)
				}
			}
			out, stderr, err = runAgentCmd(t, append(args, "--json")...)
			if err != nil || stderr != "" {
				t.Fatalf("err=%v stderr=%s", err, stderr)
			}
			var envelope struct {
				Data json.RawMessage `json:"data"`
			}
			if err := json.Unmarshal([]byte(out), &envelope); err != nil {
				t.Fatal(err)
			}
			// Typed response encoding adds optional null fields; verify every fixture
			// field recursively while allowing those existing additions.
			var want, got any
			if err := json.Unmarshal([]byte(payload), &want); err != nil {
				t.Fatal(err)
			}
			if err := json.Unmarshal(envelope.Data, &got); err != nil {
				t.Fatal(err)
			}
			assertExperimentResultJSON(t, want, got)
		})
	}
}

func assertExperimentResultJSON(t *testing.T, want, got any) {
	t.Helper()
	switch expected := want.(type) {
	case map[string]any:
		actual, ok := got.(map[string]any)
		if !ok {
			t.Fatalf("expected object, got %v", got)
		}
		for key, value := range expected {
			assertExperimentResultJSON(t, value, actual[key])
		}
	case []any:
		actual, ok := got.([]any)
		if !ok || len(actual) != len(expected) {
			t.Fatalf("array mismatch: want=%v got=%v", want, got)
		}
		for i, value := range expected {
			assertExperimentResultJSON(t, value, actual[i])
		}
	default:
		if want != got {
			t.Fatalf("JSON value changed: want=%v got=%v", want, got)
		}
	}
}

func TestExperimentShowFallsBackOnlyOnExpandedForbidden(t *testing.T) {
	for _, tc := range []struct {
		name                                  string
		expandedStatus, plainStatus, requests int
		jsonMode, success                     bool
	}{
		{"human fallback", 403, 200, 2, false, true},
		{"JSON fallback", 403, 200, 2, true, true},
		{"fallback forbidden", 403, 403, 2, true, false},
		{"not found", 404, 200, 1, true, false},
		{"unauthorized", 401, 200, 1, true, false},
		{"invalid request", 422, 200, 1, true, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			requests := 0
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				requests++
				status := tc.expandedStatus
				if requests == 1 {
					if r.URL.Query().Get("expand") != "offering.paywall" {
						t.Errorf("missing expansion: %s", r.URL.RawQuery)
					}
				} else {
					if r.URL.Query().Has("expand") {
						t.Errorf("fallback still expanded: %s", r.URL.RawQuery)
					}
					status = tc.plainStatus
				}
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(status)
				if status != http.StatusOK {
					_, _ = io.WriteString(w, `{"type":"forbidden","message":"Denied"}`)
					return
				}
				_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"draft","offering_a":{"id":"ofrng_a"}}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			args := []string{"experiments", "show", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
			if tc.jsonMode {
				args = append(args, "--json")
			}
			out, stderr, err := runAgentCmd(t, args...)
			if (err == nil) != tc.success || requests != tc.requests {
				t.Fatalf("err=%v requests=%d want=%d", err, requests, tc.requests)
			}
			if tc.success {
				if !strings.Contains(out, "exp1") || !strings.Contains(stderr, "project_configuration:offerings:read") {
					t.Fatalf("missing experiment or warning: stdout=%s stderr=%s", out, stderr)
				}
				if tc.jsonMode {
					var envelope map[string]any
					if err := json.Unmarshal([]byte(out), &envelope); err != nil {
						t.Fatalf("invalid JSON: %v", err)
					}
				}
			} else if strings.Contains(stderr, "Paywall details are unavailable") {
				t.Fatalf("warned despite failed fallback: %s", stderr)
			}
		})
	}
}

func TestExperimentStartRequiresApprovalBeforeMutation(t *testing.T) {
	mutations := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodPost {
			mutations++
			_, _ = io.WriteString(w, `{"object":"experiment","id":"exp1","display_name":"New paywall","status":"running","created_at":1,"updated_at":2}`)
			return
		}
		_, _ = io.WriteString(w, `{"object":"experiment","id":"exp1","display_name":"New paywall","status":"draft","created_at":1,"updated_at":2,"enrollment_percentage":50,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	args := []string{"experiments", "start", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
	_, _, err := runAgentCmd(t, args...)
	if err == nil || !strings.Contains(err.Error(), "--yes") || mutations != 0 {
		t.Fatalf("expected approval error before mutation; err=%v mutations=%d", err, mutations)
	}
	args = append(args, "--yes", "--json")
	out, stderr, err := runAgentCmd(t, args...)
	if err != nil || stderr != "" || mutations != 1 || !strings.Contains(out, `"status": "running"`) {
		t.Fatalf("approved start failed: err=%v stderr=%q mutations=%d out=%s", err, stderr, mutations, out)
	}
}

func TestExperimentResumeRequiresApprovalBeforeMutation(t *testing.T) {
	mutations := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodPost {
			mutations++
			_, _ = io.WriteString(w, `{"id":"exp1","display_name":"New paywall","status":"running"}`)
			return
		}
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"New paywall","status":"paused","enrollment_percentage":50,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	args := []string{"experiments", "resume", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
	_, stderr, err := runAgentCmd(t, args...)
	if err == nil || !strings.Contains(err.Error(), "--yes") || mutations != 0 || !strings.Contains(stderr, "Control") {
		t.Fatalf("expected reviewed approval before resume; err=%v mutations=%d stderr=%q", err, mutations, stderr)
	}
	args = append(args, "--yes", "--json")
	_, _, err = runAgentCmd(t, args...)
	if err != nil || mutations != 1 {
		t.Fatalf("approved resume failed: err=%v mutations=%d", err, mutations)
	}
}

func TestExperimentPauseShowsReadableResult(t *testing.T) {
	mutations := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		status := "running"
		if r.Method == http.MethodPost {
			mutations++
			status = "paused"
		}
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Paywall test","status":"`+status+`","offering_a":{"id":"ofrng_a","display_name":"Control"},"offering_b":{"id":"ofrng_b","display_name":"Treatment"},"targeting_conditions":[{"field":"platform","operator":"in","value":["ios"]}],"placements":{"placement_offerings":[{"placement_identifier":"onboarding","offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}]}}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	args := []string{"experiments", "pause", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
	_, preview, err := runAgentCmd(t, args...)
	if err == nil || !strings.Contains(err.Error(), "--yes") || mutations != 0 || !strings.Contains(preview, "platform in ios") {
		t.Fatalf("expected reviewed approval before pause: err=%v mutations=%d preview=%q", err, mutations, preview)
	}
	out, _, err := runAgentCmd(t, append(args, "--yes")...)
	if err != nil {
		t.Fatal(err)
	}
	if mutations != 1 {
		t.Fatalf("approved pause made %d mutations, want 1", mutations)
	}
	for _, want := range []string{"ofrng_a (Control)", "platform in ios", "onboarding", "Treatment ofrng_b"} {
		if !strings.Contains(out, want) {
			t.Fatalf("missing %q from pause result: %s", want, out)
		}
	}
}

func TestRunningExperimentUpdateShowsChangesBeforeApproval(t *testing.T) {
	mutations := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodPost {
			mutations++
		}
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"New paywall","status":"running","enrollment_percentage":50,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	configPath := filepath.Join(t.TempDir(), "changes.json")
	if err := os.WriteFile(configPath, []byte(`{"enrollment_percentage":80}`), 0o600); err != nil {
		t.Fatal(err)
	}
	_, stderr, err := runAgentCmd(t, "experiments", "update", "exp1", "--config", configPath, "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err == nil || !strings.Contains(err.Error(), "--yes") || mutations != 0 || !strings.Contains(stderr, "Change enrollment percentage") || !strings.Contains(stderr, "80") {
		t.Fatalf("expected reviewed approval before update; err=%v mutations=%d stderr=%q", err, mutations, stderr)
	}
}

func TestExperimentUpdateRejectsFieldsAfterStart(t *testing.T) {
	for _, tc := range []struct {
		name, status, config, want string
	}{
		{"running name", "running", `{"display_name":"Changed"}`, "only enrollment_percentage"},
		{"running mixed fields", "running", `{"enrollment_percentage":80,"notes":"Changed"}`, "only enrollment_percentage"},
		{"paused enrollment", "paused", `{"enrollment_percentage":80}`, "only drafts and running experiments"},
		{"stopped enrollment", "stopped", `{"enrollment_percentage":80}`, "only drafts and running experiments"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			mutations := 0
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				if r.Method == http.MethodPost {
					mutations++
				}
				_, _ = fmt.Fprintf(w, `{"id":"exp1","display_name":"Original","status":%q,"enrollment_percentage":50}`, tc.status)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			configPath := filepath.Join(t.TempDir(), "changes.json")
			if err := os.WriteFile(configPath, []byte(tc.config), 0o600); err != nil {
				t.Fatal(err)
			}
			_, _, err := runAgentCmd(t, "experiments", "update", "exp1", "--config", configPath,
				"--project-id", "proj", "--api-key", "sk_test", "--yes", "--no-input")
			if err == nil || !strings.Contains(err.Error(), tc.want) || mutations != 0 {
				t.Fatalf("err=%v mutations=%d, want %q and no mutation", err, mutations, tc.want)
			}
		})
	}
}

func TestExperimentCreateListsMissingFlags(t *testing.T) {
	_, _, err := runCmd(t, "experiments", "create", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err == nil {
		t.Fatal("expected missing input error")
	}
	for _, flag := range []string{"--name", "--control", "--treatment", "--enrollment"} {
		if !strings.Contains(err.Error(), flag) {
			t.Fatalf("missing %s from error: %v", flag, err)
		}
	}
}

func TestExperimentDuplicateCopiesConfigurationIntoDraft(t *testing.T) {
	var posted map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.Method == http.MethodGet {
			_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Original","status":"running","enrollment_percentage":40,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"},"offering_c":{"id":"ofrng_c"},"targeting_conditions":[{"field":"platform","operator":"in","value":["ios"]}],"placements":{"fallback_offering_a":{"id":"ofrng_fa"},"placement_offerings":[{"placement_identifier":"onboarding","offering_a":{"id":"ofrng_pa"},"offering_b":{"id":"ofrng_pb"}}]},"experiment_duration_settings":{"chance_to_win_percentage":95},"primary_metric":"initial_conversion_rate","enrollment_mode":"only_new"}`)
			return
		}
		if r.URL.Path != "/projects/proj/experiments" {
			t.Errorf("unexpected mutation path: %s", r.URL.Path)
		}
		if err := json.NewDecoder(r.Body).Decode(&posted); err != nil {
			t.Error(err)
		}
		_, _ = io.WriteString(w, `{"id":"exp2","display_name":"New test","status":"draft"}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	_, _, err := runAgentCmd(t, "experiments", "duplicate", "exp1", "--name", "New test", "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
	if err != nil {
		t.Fatal(err)
	}
	if posted["display_name"] != "New test" || posted["offering_c_id"] != "ofrng_c" || posted["primary_metric"] != "initial_conversion_rate" {
		t.Fatalf("missing copied fields: %#v", posted)
	}
	placements := posted["placements"].(map[string]any)
	rows := placements["placement_offerings"].([]any)
	if placements["fallback_offering_a_id"] != "ofrng_fa" || rows[0].(map[string]any)["offering_b_id"] != "ofrng_pb" {
		t.Fatalf("placement IDs not copied: %#v", placements)
	}
	if _, exists := posted["status"]; exists {
		t.Fatalf("status should not be copied: %#v", posted)
	}
}

func TestExperimentStopAndDeleteRequireApproval(t *testing.T) {
	for _, tc := range []struct {
		command string
		method  string
		path    string
	}{
		{"stop", http.MethodPost, "/projects/proj/experiments/exp1/actions/stop"},
		{"delete", http.MethodDelete, "/projects/proj/experiments/exp1"},
	} {
		t.Run(tc.command, func(t *testing.T) {
			mutations := 0
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodGet && r.URL.Path == "/projects/proj/experiments/exp1" {
					w.Header().Set("Content-Type", "application/json")
					_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"draft"}`)
					return
				}
				if r.Method != tc.method || r.URL.Path != tc.path {
					t.Errorf("unexpected request: %s %s", r.Method, r.URL.Path)
				}
				mutations++
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"stopped"}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			args := []string{"experiments", tc.command, "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input"}
			_, preview, err := runAgentCmd(t, args...)
			if tc.command == "stop" && (!strings.Contains(preview, "Test") || !strings.Contains(preview, "Status") || !strings.Contains(preview, "draft")) {
				t.Fatalf("missing stop preview: %s", preview)
			}
			if err == nil || !strings.Contains(err.Error(), "--yes") || mutations != 0 {
				t.Fatalf("expected approval before mutation: err=%v mutations=%d", err, mutations)
			}
			_, _, err = runAgentCmd(t, append(args, "--yes", "--json")...)
			if err != nil || mutations != 1 {
				t.Fatalf("approved %s failed: err=%v mutations=%d", tc.command, err, mutations)
			}
		})
	}
}

func TestExperimentDeleteRejectsNonDraft(t *testing.T) {
	for _, status := range []string{"running", "paused", "stopped"} {
		t.Run(status, func(t *testing.T) {
			mutations := 0
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodDelete {
					mutations++
				}
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"`+status+`"}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			_, _, err := runAgentCmd(t, "experiments", "delete", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--yes", "--no-input")
			if err == nil || !strings.Contains(err.Error(), "only draft experiments can be deleted") || mutations != 0 {
				t.Fatalf("expected non-draft guard: err=%v mutations=%d", err, mutations)
			}
		})
	}
}

func TestExperimentCreateAndApprovedUpdate(t *testing.T) {
	var created, updated map[string]any
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/projects/proj/experiments":
			if err := json.NewDecoder(r.Body).Decode(&created); err != nil {
				t.Error(err)
			}
			_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"draft","enrollment_percentage":50,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
		case r.Method == http.MethodGet && r.URL.Path == "/projects/proj/experiments/exp1":
			_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"running","enrollment_percentage":50,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
		case r.Method == http.MethodPost && r.URL.Path == "/projects/proj/experiments/exp1":
			if err := json.NewDecoder(r.Body).Decode(&updated); err != nil {
				t.Error(err)
			}
			_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test","status":"running","enrollment_percentage":60,"offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"}}`)
		default:
			t.Errorf("unexpected request: %s %s", r.Method, r.URL.Path)
		}
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	_, _, err := runAgentCmd(t, "experiments", "create", "--name", "Test", "--control", "ofrng_a", "--treatment", "ofrng_b", "--enrollment", "50", "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
	if err != nil || created["enrollment_percentage"] != float64(50) {
		t.Fatalf("create failed: err=%v body=%v", err, created)
	}
	configPath := filepath.Join(t.TempDir(), "update.json")
	if err := os.WriteFile(configPath, []byte(`{"enrollment_percentage":60}`), 0o600); err != nil {
		t.Fatal(err)
	}
	_, _, err = runAgentCmd(t, "experiments", "update", "exp1", "--config", configPath, "--project-id", "proj", "--api-key", "sk_test", "--yes", "--json", "--no-input")
	if err != nil || updated["enrollment_percentage"] != float64(60) {
		t.Fatalf("approved update failed: err=%v body=%v", err, updated)
	}
}

func TestExperimentUpdateRejectsInvalidEnrollmentBeforeRequest(t *testing.T) {
	for _, value := range []string{"0", "101", "null", `"5"`, "5.5"} {
		t.Run(value, func(t *testing.T) {
			configPath := filepath.Join(t.TempDir(), "update.json")
			if err := os.WriteFile(configPath, []byte(`{"enrollment_percentage":`+value+`}`), 0o600); err != nil {
				t.Fatal(err)
			}
			_, _, err := runAgentCmd(t, "experiments", "update", "exp1", "--config", configPath, "--project-id", "proj", "--api-key", "sk_test", "--no-input")
			if err == nil || !strings.Contains(err.Error(), "1 to 100") {
				t.Fatalf("expected local enrollment validation, got %v", err)
			}
		})
	}
}

func TestExperimentUpdatePreservesOmittedAndNullAudience(t *testing.T) {
	for _, tc := range []struct {
		name, config string
		present      bool
		value        any
	}{
		{"omitted", `{"notes":"Keep targeting"}`, false, nil},
		{"cleared", `{"audience_id":null}`, true, nil},
		{"replaced", `{"audience_id":"aud_new"}`, true, "aud_new"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var posted map[string]any
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodPost {
					if err := json.NewDecoder(r.Body).Decode(&posted); err != nil {
						t.Error(err)
					}
				}
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Original","status":"draft","audience_id":"aud_original"}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			configPath := filepath.Join(t.TempDir(), "update.json")
			if err := os.WriteFile(configPath, []byte(tc.config), 0o600); err != nil {
				t.Fatal(err)
			}
			_, _, err := runAgentCmd(t, "experiments", "update", "exp1", "--config", configPath, "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
			value, present := posted["audience_id"]
			if err != nil || posted == nil || present != tc.present || value != tc.value {
				t.Fatalf("err=%v posted=%v; audience present=%v value=%v", err, posted, present, value)
			}
		})
	}
}

func TestExperimentUpdateSchemaExplainsAudienceOmissionAndNull(t *testing.T) {
	out, _, err := runCmd(t, "schema", "experiments", "update", "--json")
	if err != nil {
		t.Fatal(err)
	}
	var envelope struct {
		Data struct {
			ConfigFields struct {
				Properties struct {
					Audience struct {
						Type        []string `json:"type"`
						Description string   `json:"description"`
					} `json:"audience_id"`
				} `json:"properties"`
			} `json:"config_fields"`
		} `json:"data"`
	}
	if err := json.Unmarshal([]byte(out), &envelope); err != nil {
		t.Fatal(err)
	}
	audience := envelope.Data.ConfigFields.Properties.Audience
	if strings.Join(audience.Type, ",") != "string,null" || !strings.Contains(audience.Description, "Omit to keep") || !strings.Contains(audience.Description, "Set null to clear") {
		t.Fatalf("audience schema does not explain both behaviors: %+v", audience)
	}
}

func TestExperimentCreateAudienceWithEmptyConditions(t *testing.T) {
	for _, conditions := range []string{"null", "[]", `[{"field":"country","operator":"in","value":["US"]}]`} {
		t.Run(conditions, func(t *testing.T) {
			posted := false
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				posted = true
				w.Header().Set("Content-Type", "application/json")
				_, _ = io.WriteString(w, `{"id":"exp1","status":"draft"}`)
			}))
			t.Cleanup(srv.Close)
			t.Setenv("RC_BASE_URL", srv.URL)
			path := filepath.Join(t.TempDir(), "create.json")
			body := `{"display_name":"Test","offering_a_id":"a","offering_b_id":"b","enrollment_percentage":50,"audience_id":"aud1","targeting_conditions":` + conditions + `}`
			if err := os.WriteFile(path, []byte(body), 0600); err != nil {
				t.Fatal(err)
			}
			_, _, err := runAgentCmd(t, "experiments", "create", "--config", path, "--project-id", "proj", "--api-key", "sk_test", "--json", "--no-input")
			wantSuccess := conditions == "null" || conditions == "[]"
			if (err == nil) != wantSuccess || posted != wantSuccess {
				t.Fatalf("err=%v posted=%v wantSuccess=%v", err, posted, wantSuccess)
			}
		})
	}
}

func TestExperimentDeleteSanitizesConfirmation(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = io.WriteString(w, `{"id":"exp1","display_name":"Test\u001b[31m\nforged","status":"draft"}`)
	}))
	t.Cleanup(srv.Close)
	t.Setenv("RC_BASE_URL", srv.URL)
	_, _, err := runAgentCmd(t, "experiments", "delete", "exp1", "--project-id", "proj", "--api-key", "sk_test", "--no-input")
	if err == nil || !strings.Contains(err.Error(), "Test") || !strings.Contains(err.Error(), "exp1") || strings.ContainsAny(err.Error(), "\x1b\n") {
		t.Fatalf("unsafe confirmation: %v", err)
	}
}

func TestExperimentPlacementsRejectIgnoredFallbacksBeforeMutation(t *testing.T) {
	for _, command := range []string{"create", "update"} {
		for _, placement := range []string{`{"fallback_offering_a_id":"a"}`, `{"fallback_offering_b_id":"b","placement_offerings":[]}`, `{"fallback_offering_c_id":"c","placement_offerings":null}`, `{"fallback_offering_d_id":"d","placement_offerings":[]}`} {
			t.Run(command+placement, func(t *testing.T) {
				mutations := 0
				srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					if r.Method != http.MethodGet {
						mutations++
					}
					w.Header().Set("Content-Type", "application/json")
					_, _ = io.WriteString(w, `{"id":"exp1","status":"draft"}`)
				}))
				t.Cleanup(srv.Close)
				t.Setenv("RC_BASE_URL", srv.URL)
				config := `{"placements":` + placement + `}`
				args := []string{"experiments", command}
				if command == "create" {
					args = append(args, "--name", "Test", "--control", "a", "--treatment", "b", "--enrollment", "50")
				} else {
					args = append(args, "exp1")
				}
				path := filepath.Join(t.TempDir(), "placements.json")
				if err := os.WriteFile(path, []byte(config), 0600); err != nil {
					t.Fatal(err)
				}
				args = append(args, "--config", path, "--project-id", "proj", "--api-key", "sk_test", "--no-input", "--yes")
				_, _, err := runAgentCmd(t, args...)
				if err == nil || !strings.Contains(err.Error(), "at least one placement_offerings") || mutations != 0 {
					t.Fatalf("err=%v mutations=%d", err, mutations)
				}
			})
		}
	}
}
