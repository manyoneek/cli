package cli_test

// Output snapshot tests: lock the human-mode layout and copy of
// representative commands into golden files so design regressions fail CI
// instead of being discovered by a human squinting at a terminal.
//
// Regenerate after intentional design changes:
//
//	UPDATE_SNAPSHOTS=1 go test ./internal/cli/ -run TestOutputSnapshots
//
// Then eyeball `make preview` (renders the goldens to SVGs) and commit both.
// Goldens are colorless (tests run without a TTY); color choices live in
// internal/output/brand.go and are reviewed there.

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/revenuecat/cli/internal/cli"
)

func snapshotServer(t *testing.T) *httptest.Server {
	t.Helper()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch {
		case strings.HasSuffix(r.URL.Path, "/experiments/exp_snap/actions/stop"):
			io.WriteString(w, `{"id":"exp_snap","display_name":"Price paywall","status":"stopped"}`)
		case strings.HasSuffix(r.URL.Path, "/targeting_rules/chkptrule_snap"):
			if r.Method == http.MethodPost {
				io.WriteString(w, `{"id":"chkptrule_snap","rule_type":"checkpoint","state":"active","display_name":"Onboarding","flow_id":"wf_new","audience_id":"aud_new","checkpoints":[{"checkpoint_id":"chkpt_new","position":0}]}`)
			} else {
				io.WriteString(w, `{"id":"chkptrule_snap","rule_type":"checkpoint","state":"scheduled","display_name":"Onboarding","flow_id":"wf_original","audience_id":"aud_original","checkpoints":[{"checkpoint_id":"chkpt_original","position":0}],"schedule":{"start_date":"2030-12-01T00:00:00Z"}}`)
			}
		case strings.HasSuffix(r.URL.Path, "/targeting_rules/trle_snap"):
			io.WriteString(w, `{"object":"targeting_rule","id":"trle_snap","rule_type":"legacy","state":"active","display_name":"US annual paywall","offering_id":"ofrng_us","conditions":[{"field":"platform","operator":"in","value":["ios"]}],"placements":{"fallback_offering_id":"ofrng_default","placement_offerings":[{"placement_identifier":"onboarding","offering_id":"ofrng_us"}]},"schedule":{"start_date":"2026-09-25T12:00:00Z","end_date":null}}`)
		case strings.HasSuffix(r.URL.Path, "/targeting_rules"):
			if r.Method == http.MethodPost {
				var body struct {
					DisplayName string `json:"display_name"`
				}
				if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
					t.Error(err)
				}
				if body.DisplayName == "Holiday paywall" {
					io.WriteString(w, `{"object":"targeting_rule","id":"trle_holiday","rule_type":"legacy","state":"active","display_name":"Holiday paywall","offering_id":"ofrng_holiday","schedule":{"start_date":"2030-12-01T00:00:00Z","end_date":"2030-12-31T23:59:59Z"}}`)
				} else if body.DisplayName == "Onboarding" {
					io.WriteString(w, `{"id":"chkptrule_snap","rule_type":"checkpoint","state":"active","display_name":"Onboarding","flow_id":"wf_new","audience_id":"aud_new","checkpoints":[{"checkpoint_id":"chkpt_new","position":3}]}`)
				} else {
					io.WriteString(w, `{"object":"targeting_rule","id":"trle_snap","rule_type":"legacy","state":"active","display_name":"Default paywall","offering_id":"ofrng_default"}`)
				}
			} else {
				io.WriteString(w, `{"object":"list","items":[{"object":"targeting_rule","id":"trle_snap","rule_type":"legacy","state":"active","display_name":"US annual paywall","offering_id":"ofrng_us"}],"next_page":null,"url":"/projects/proj_snap/targeting_rules"}`)
			}
		case strings.HasSuffix(r.URL.Path, "/experiments/exp_snap/actions/start"):
			io.WriteString(w, `{"object":"experiment","id":"exp_snap","display_name":"New paywall","status":"running","created_at":1784297950368,"updated_at":1784297950368}`)

		case strings.HasSuffix(r.URL.Path, "/experiments"):
			io.WriteString(w, `{"items":[{"id":"exp_snap","display_name":"Four variants","status":"draft","offering_a":{"id":"ofrng_a"},"offering_b":{"id":"ofrng_b"},"offering_c":{"id":"ofrng_c"},"offering_d":{"id":"ofrng_d"}}],"next_page":null}`)
		case strings.HasSuffix(r.URL.Path, "/experiments/exp_snap"):
			io.WriteString(w, `{"object":"experiment","id":"exp_snap","display_name":"Price — paywall","status":"draft","created_at":1784297950368,"updated_at":1784297950368,"total_running_time_seconds":1989824,"enrollment_percentage":50,"offering_a":{"id":"ofrng_control","display_name":"Control","paywall_id":"pw_control"},"offering_b":{"id":"ofrng_treatment","display_name":"Treatment","paywall_id":"pw_treatment"},"offering_c":{"id":"ofrng_extra"},"targeting_conditions":[{"field":"platform","operator":"in","value":["ios"]}],"placements":{"placement_offerings":[{"placement_identifier":"onboarding","offering_a":{"id":"ofrng_control"},"offering_b":{"id":"ofrng_treatment"}}]},"experiment_type":"paywall_design","primary_metric":"initial_conversion_rate","secondary_metrics":["realized_ltv_per_customer","trial_conversion_rate"],"enrollment_mode":"only_new","experiment_duration_settings":{"chance_to_win_percentage":95},"conflicts":[{"id":"exp_other"}]}`)
		case strings.HasSuffix(r.URL.Path, "/experiments/exp_opaque/results"):
			fixture, err := os.ReadFile("testdata/experiment-results-opaque-keys.json")
			if err != nil {
				t.Error(err)
				w.WriteHeader(http.StatusInternalServerError)
				return
			}
			_, _ = w.Write(fixture)
		case strings.HasSuffix(r.URL.Path, "/experiments/exp_snap/results"):
			io.WriteString(w, `{"object":"experiment_results","currency":"USD","sections":[{"object":"experiment_results_section","section":"Conversion","metrics":[{"name":"trial_conversion_rate","unit":"%"}],"segments":[{"object":"experiment_results_segment","id":"total","display_name":"Total","is_total":true}],"values":[{"object":"experiment_results_value","metric":0,"segment":0,"variant":"Control","value":12.5,"change":null,"credible_interval":null,"lift_credible_interval":null},{"object":"experiment_results_value","metric":0,"segment":0,"variant":"Treatment","value":15.0,"change":20,"credible_interval":null,"lift_credible_interval":null}]}],"statistics":[{"object":"experiment_results_statistic","metric_name":"trial_conversion_rate","variants":[{"object":"experiment_results_variant_statistic","name":"Control","chance_to_win":null,"chance_to_win_status":"unavailable","credible_interval_lower":0.1,"credible_interval_upper":0.15,"credible_interval_status":"ok","lift_credible_interval_lower":null,"lift_credible_interval_upper":null,"lift_credible_interval_status":"unavailable"},{"object":"experiment_results_variant_statistic","name":"Treatment","chance_to_win":0.98,"chance_to_win_status":"ok","credible_interval_lower":0.11,"credible_interval_upper":0.18,"credible_interval_status":"ok","lift_credible_interval_lower":-5,"lift_credible_interval_upper":22,"lift_credible_interval_status":"ok"}]}],"predicted_ltv":null}`)
		case strings.HasSuffix(r.URL.Path, "/offerings/ofrng_snap"):
			io.WriteString(w, `{"object":"offering","id":"ofrng_snap","lookup_key":"default","display_name":"Default","is_current":true,"created_at":1784297950368,"project_id":"proj_snap"}`)
		case strings.HasSuffix(r.URL.Path, "/apps/app_snap1"):
			io.WriteString(w, `{"object":"app","id":"app_snap1","name":"Moodly (App Store)","type":"app_store","created_at":1784241909459,"project_id":"proj_snap","app_store":{"bundle_id":"com.example.moodly","subscription_key_configured":true,"app_store_connect_api_key_configured":false}}`)
		case strings.HasSuffix(r.URL.Path, "/projects"):
			io.WriteString(w, `{"object":"list","items":[{"id":"proj_snap","name":"Moodly"},{"id":"proj_snap2","name":"Moodly Staging"}],"next_page":null}`)
		case strings.HasSuffix(r.URL.Path, "/proj_snap2/apps"):
			io.WriteString(w, `{"object":"list","items":[{"object":"app","id":"app_snap3","name":"Moodly Staging (App Store)","type":"app_store","created_at":1784241909459,"project_id":"proj_snap2","app_store":{"bundle_id":"com.example.moodly","subscription_key_configured":true,"app_store_connect_api_key_configured":true}}],"next_page":null,"url":"/apps"}`)
		case strings.HasSuffix(r.URL.Path, "/apps"):
			io.WriteString(w, `{"object":"list","items":[{"object":"app","id":"app_snap1","name":"Moodly (App Store)","type":"app_store","created_at":1784241909459,"project_id":"proj_snap","app_store":{"bundle_id":"com.example.moodly","subscription_key_configured":true,"app_store_connect_api_key_configured":false}},{"object":"app","id":"app_snap2","name":"Test Store","type":"test_store","created_at":1784241905823,"project_id":"proj_snap"}],"next_page":null,"url":"/apps"}`)
		default:
			w.WriteHeader(http.StatusNotFound)
			io.WriteString(w, `{"object":"error","type":"resource_missing","message":"not found"}`)
		}
	}))
	t.Cleanup(server.Close)
	return server
}

func TestOutputSnapshots(t *testing.T) {
	server := snapshotServer(t)
	t.Setenv("RC_BASE_URL", server.URL)

	scenarios := []struct {
		name string
		args []string
	}{
		{"version", []string{"version"}},
		{"auth-status-logged-out", []string{"auth", "status", "--no-input"}},
		{"offerings-show", []string{"offerings", "show", "ofrng_snap", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-list", []string{"experiments", "list", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-show", []string{"experiments", "show", "exp_snap", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-results", []string{"experiments", "results", "exp_snap", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-results-opaque-keys", []string{"experiments", "results", "exp_opaque", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-stop", []string{"experiments", "stop", "exp_snap", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"experiments-start", []string{"experiments", "start", "exp_snap", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-update-checkpoint", []string{"targeting", "update", "chkptrule_snap", "--config", "testdata/checkpoint-targeting-update.json", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-list", []string{"targeting", "list", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-show", []string{"targeting", "show", "trle_snap", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-create-active", []string{"targeting", "create", "--name", "Default paywall", "--offering", "ofrng_default", "--state", "active", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-create-checkpoint", []string{"targeting", "create", "--config", "testdata/checkpoint-targeting-create.json", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"targeting-create-scheduled", []string{"targeting", "create", "--config", "testdata/scheduled-targeting.json", "--yes", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"apps-list", []string{"apps", "list", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"apps-list-all-projects", []string{"apps", "list", "--all-projects", "--bundle-id", "com.example.moodly", "--no-input", "--api-key", "sk_snap"}},
		{"error-not-found", []string{"offerings", "show", "ofrng_missing", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
		{"apps-apple-setup", []string{"apps", "apple", "setup", "app_snap1", "--no-input", "--project-id", "proj_snap", "--api-key", "sk_snap"}},
	}

	for _, sc := range scenarios {
		t.Run(sc.name, func(t *testing.T) {
			t.Setenv("RC_CONFIG_DIR", t.TempDir())
			var b strings.Builder
			fmt.Fprintf(&b, "$ rc %s\n", strings.Join(sc.args, " "))
			root := cli.NewRootCmd("test")
			// A shared writer preserves terminal ordering across stdout and stderr.
			root.SetOut(&b)
			root.SetErr(&b)
			root.SetArgs(sc.args)
			err := root.ExecuteContext(context.Background())
			if err != nil {
				fmt.Fprintf(&b, "(exit: %v)\n", err)
			}
			got := b.String()

			golden := filepath.Join("testdata", "snapshots", sc.name+".golden")
			if os.Getenv("UPDATE_SNAPSHOTS") != "" {
				if err := os.MkdirAll(filepath.Dir(golden), 0o755); err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(golden, []byte(got), 0o644); err != nil {
					t.Fatal(err)
				}
				return
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatalf("missing golden %s — run UPDATE_SNAPSHOTS=1 go test ./internal/cli/ -run TestOutputSnapshots", golden)
			}
			if string(want) != got {
				t.Errorf("output changed vs %s\n--- want\n%s\n--- got\n%s\nIf intentional: UPDATE_SNAPSHOTS=1 go test ./internal/cli/ -run TestOutputSnapshots, review `make preview`, commit both.", golden, want, got)
			}
		})
	}
}
