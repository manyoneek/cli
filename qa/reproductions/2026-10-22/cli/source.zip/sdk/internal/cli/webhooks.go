package cli

import (
	"context"
	"fmt"

	"github.com/charmbracelet/huh"
	"github.com/spf13/cobra"

	"github.com/revenuecat/cli/internal/api"
	"github.com/revenuecat/cli/internal/output"
	"github.com/revenuecat/cli/internal/tui"
)

// Webhooks is `rc webhooks` in CLI surface but hits /integrations/webhooks
// on the wire (the bare /integrations URL 404s; sub-type is part of the path).
// User-facing name follows what users say, not the API URL structure.

func newWebhooksCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:     "webhooks",
		Aliases: []string{"webhook"},
		Short:   "Manage webhook integrations",
		Long: `Webhooks send RevenueCat server-to-server notifications whenever a subscription
or purchase event happens — initial purchases, renewals, cancellations, billing
issues — so your backend can stay in sync and trigger automations. Each webhook
has a name and a delivery URL, scoped to the project.`,
		Example: `  rc webhooks list
  rc webhooks create --name "Backend sync" --url https://api.example.com/revenuecat`,
	}
	cmd.AddCommand(
		newWebhooksListCmd(),
		newWebhooksShowCmd(),
		newWebhooksCreateCmd(),
		newWebhooksUpdateCmd(),
		newWebhooksDeleteCmd(),
	)
	return cmd
}

func newWebhooksListCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "list",
		Short: "List webhooks",
		Long:  `Lists the webhook integrations configured for the project, with each delivery URL and environment.`,
		Example: `  rc webhooks list
  rc webhooks list --json | jq '.data.items[].url'`,
		RunE: func(cmd *cobra.Command, _ []string) error {
			rt := RuntimeFrom(cmd.Context())
			projectID, err := requireProject(rt)
			if err != nil {
				return err
			}
			client, err := rt.API()
			if err != nil {
				return err
			}
			page, err := client.Webhooks.List(cmd.Context(), projectID)
			if err != nil {
				return err
			}

			if rt.CanPrompt() {
				items := make([]tui.BrowserItem, len(page.Items))
				for i, w := range page.Items {
					items[i] = webhookToItem(projectID, w)
				}
				return tui.RunBrowserTable("Webhooks", []string{"ID", "NAME", "URL", "ENVIRONMENT"}, items)
			}

			rows := make([][]string, 0, len(page.Items))
			for _, w := range page.Items {
				rows = append(rows, []string{w.ID, w.Name, w.URL, w.Environment, formatMillis(int64(w.CreatedAt))})
			}
			return rt.Out.RenderTable(output.Table{
				Columns: []string{"ID", "NAME", "URL", "ENVIRONMENT", "CREATED"},
				Rows:    rows,
				Raw:     page,
			})
		},
	}
}

// ── browser helpers ──────────────────────────────────────────────────────────

func webhookToItem(projectID string, w api.Webhook) tui.BrowserItem {
	return tui.BrowserItem{
		ID:     w.ID,
		Label:  w.URL,
		Meta:   w.Environment,
		Row:    []string{w.ID, w.Name, w.URL, w.Environment},
		WebURL: dashboardURL(projectID, "integrations"),
		Fields: []tui.BrowserField{
			{Key: "ID", Value: w.ID},
			{Key: "Name", Value: w.Name},
			{Key: "URL", Value: w.URL},
			{Key: "Environment", Value: w.Environment},
			{Key: "Created", Value: formatMillis(int64(w.CreatedAt))},
		},
	}
}

func newWebhooksShowCmd() *cobra.Command {
	return &cobra.Command{
		Use:     "show [id]",
		Short:   "Show a webhook",
		Long:    `Shows a webhook's name, delivery URL, and environment. Omit the ID in a terminal to pick from a list.`,
		Example: "  rc webhooks show wh_abc\n  rc webhooks show                 # pick interactively",
		Args:    cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			rt := RuntimeFrom(cmd.Context())
			projectID, err := requireProject(rt)
			if err != nil {
				return err
			}
			client, err := rt.API()
			if err != nil {
				return err
			}
			webhookID, err := requireID(rt, argAt(args, 0), "webhook", func() ([]PickerItem, error) {
				return webhookPickerItems(cmd.Context(), client, projectID)
			})
			if err != nil {
				return err
			}
			w, err := client.Webhooks.Get(cmd.Context(), projectID, webhookID)
			if err != nil {
				return err
			}
			if rt.CanPrompt() {
				item := webhookToItem(projectID, *w)
				return tui.RunBrowser("Webhook", []tui.BrowserItem{item})
			}
			return rt.Out.Render(w)
		},
	}
}

func newWebhooksCreateCmd() *cobra.Command {
	var name, urlStr string
	cmd := &cobra.Command{
		Use:     "create",
		Short:   "Create a webhook",
		Long:    `Creates a webhook: RevenueCat POSTs event notifications to the given URL as subscription and purchase events occur. Prompts for the name and URL when run interactively.`,
		Example: `  rc webhooks create --name "Backend sync" --url https://api.example.com/revenuecat`,
		RunE: func(cmd *cobra.Command, _ []string) error {
			rt := RuntimeFrom(cmd.Context())
			projectID, err := requireProject(rt)
			if err != nil {
				return err
			}
			if err := tui.Form(rt.Globals.NoInput).
				Field(huh.NewInput().Title("Name").Value(&name).Validate(tui.Required("name"))).
				Field(huh.NewInput().Title("Webhook URL").Value(&urlStr).Validate(tui.Required("URL"))).
				Run(); err != nil {
				return err
			}
			client, err := rt.API()
			if err != nil {
				return err
			}
			w, err := client.Webhooks.Create(cmd.Context(), projectID, api.WebhookCreate{Name: name, URL: urlStr})
			if err != nil {
				return err
			}
			rt.Out.Success(fmt.Sprintf("Created webhook %s", w.ID))
			return rt.Out.Render(w)
		},
	}
	cmd.Flags().StringVar(&name, "name", "", "display name (required)")
	cmd.Flags().StringVar(&urlStr, "url", "", "webhook URL (required)")
	return cmd
}

func newWebhooksUpdateCmd() *cobra.Command {
	var name, urlStr string
	cmd := &cobra.Command{
		Use:     "update [id]",
		Short:   "Update a webhook",
		Long:    `Updates a webhook's name or delivery URL. Only the flags you pass change; omit the ID in a terminal to pick from a list.`,
		Example: "  rc webhooks update wh_abc --url https://api.example.com/rc/v2\n  rc webhooks update wh_abc --name \"Prod events\"",
		Args:    cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			rt := RuntimeFrom(cmd.Context())
			projectID, err := requireProject(rt)
			if err != nil {
				return err
			}
			client, err := rt.API()
			if err != nil {
				return err
			}
			webhookID, err := requireID(rt, argAt(args, 0), "webhook", func() ([]PickerItem, error) {
				return webhookPickerItems(cmd.Context(), client, projectID)
			})
			if err != nil {
				return err
			}
			body := api.WebhookUpdate{}
			if cmd.Flags().Changed("name") {
				body.Name = &name
			}
			if cmd.Flags().Changed("url") {
				body.URL = &urlStr
			}
			w, err := client.Webhooks.Update(cmd.Context(), projectID, webhookID, body)
			if err != nil {
				return err
			}
			rt.Out.Success(fmt.Sprintf("Updated %s", w.ID))
			return rt.Out.Render(w)
		},
	}
	cmd.Flags().StringVar(&name, "name", "", "new display name")
	cmd.Flags().StringVar(&urlStr, "url", "", "new URL")
	return cmd
}

func newWebhooksDeleteCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "delete [id]",
		Short: "Delete a webhook",
		Long: `Permanently deletes a webhook integration. Future events stop being
delivered to the configured URL.

Reversibility: irreversible. Re-create the webhook if you need it back.

Confirmation: prompts under TTY; pass --yes to skip. Required under --no-input.`,
		Example: `  rc webhooks delete wh_old --yes`,
		Args:    cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			rt := RuntimeFrom(cmd.Context())
			projectID, err := requireProject(rt)
			if err != nil {
				return err
			}
			client, err := rt.API()
			if err != nil {
				return err
			}
			webhookID, err := requireID(rt, argAt(args, 0), "webhook", func() ([]PickerItem, error) {
				return webhookPickerItems(cmd.Context(), client, projectID)
			})
			if err != nil {
				return err
			}
			if err := confirmOrAbort(rt, fmt.Sprintf("Delete webhook %q?", webhookID)); err != nil {
				return err
			}
			if err := client.Webhooks.Delete(cmd.Context(), projectID, webhookID); err != nil {
				return err
			}
			rt.Out.Success(fmt.Sprintf("Deleted %s", webhookID))
			return rt.Out.Render(map[string]any{"ok": true, "id": webhookID})
		},
	}
}

// ── picker helpers ───────────────────────────────────────────────────────────

func webhookPickerItems(ctx context.Context, client *api.Client, projectID string) ([]PickerItem, error) {
	page, err := client.Webhooks.List(ctx, projectID)
	if err != nil {
		return nil, err
	}
	items := make([]PickerItem, len(page.Items))
	for i, w := range page.Items {
		items[i] = PickerItem{ID: w.ID, Label: fmt.Sprintf("%s  (%s)", w.URL, w.Environment)}
	}
	return items, nil
}
